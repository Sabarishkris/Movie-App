package com.example.movieapp.data.moviedetails

data class Rating(
    val Source: String,
    val Value: String
)