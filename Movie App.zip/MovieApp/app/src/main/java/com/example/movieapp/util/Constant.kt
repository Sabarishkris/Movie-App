package com.example.movieapp.util

object Constant {
    const val BASE_URL="http://www.omdbapi.com"
    const val API_KEY="b01f08cb"
}