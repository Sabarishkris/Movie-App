package com.example.movieapp.util

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.example.movieapp.R

//@BindingAdapter("load")
//fun loadImage(view: ImageView,url:String){
//    url?.let {
//        Glide.with(view).load(url).into(view)
//    }
object BindingAdapter {
    @JvmStatic
    @BindingAdapter("load")
    fun loadImage(view: ImageView, url: String?) {
        if (!url.isNullOrEmpty()) {
            // Use your preferred image loading library or method
            Glide.with(view.context)
                .load(url)
                .into(view)
        } else {
            // Optionally handle the case where url is null or empty
            // For example, set a placeholder or clear the image
            //view.setImageResource(R.drawable.placeholder_image)
        }
    }
}