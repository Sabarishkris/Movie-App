package com.example.movieapp.ui.details

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.movieapp.R
import com.example.movieapp.databinding.FragmentMovieDetailsBinding
import com.example.movieapp.ui.movie.MovieViewModel
import com.example.movieapp.util.Status
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MovieDetailsFragment : Fragment() {

private lateinit var binding: FragmentMovieDetailsBinding
val args:MovieDetailsFragmentArgs by navArgs()
val viewModel:MovieViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=DataBindingUtil.inflate(inflater,R.layout.fragment_movie_details, container, false)
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.backPress.setOnClickListener{
            findNavController().popBackStack()
        }
        viewModel.getMovieDetails(args.ImbdId!!)
        viewModel.movieDetails.observe(viewLifecycleOwner){
            when(it.getContentIfNotHandled()?.status){
                Status.LOADING->{
                  binding.detailsProgress.visibility=View.VISIBLE
                }
                Status.ERROR->{binding.detailsProgress.visibility=View.GONE}
                Status.SUCCESS -> {binding.detailsProgress.visibility=View.GONE
                binding.movieDetails=it.peekContent().data}
                null -> TODO()
            }
        }
    }
}