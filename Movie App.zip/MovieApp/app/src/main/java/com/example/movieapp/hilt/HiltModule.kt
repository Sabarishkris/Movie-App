package com.example.movieapp.hilt

import com.example.movieapp.remote.MovieInterface
import com.example.movieapp.ui.details.MovieDetailsRepository
import com.example.movieapp.util.Constant
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object HiltModule {
    @Provides
    @Singleton
fun provideRetrofitInterface(): MovieInterface {
    return Retrofit.Builder()
        .baseUrl(Constant.BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(MovieInterface::class.java)
}
@Provides
@Singleton
fun provideRepository(movieInterface: MovieInterface):MovieDetailsRepository{
    return MovieDetailsRepository(movieInterface)
}

}